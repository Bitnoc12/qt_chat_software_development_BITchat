tcpSocket->abort();
          tcpSocket->connectToHost(hostip, hosthost);
          if (tcpSocket->waitForConnected(30000))
          {
              QString nowstr = QDateTime::currentDateTime().currentDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz");
              QString targetClientIdentifier = "127.0.0.1"; // 替换为目标客户端的标识符
              QString message = QString("chat_send##forward##%1##%2").arg(targetClientIdentifier).arg(ui->lineEditSend->text());
              tcpSocket->write(message.toUtf8());
              tcpSocket->flush();
              ui->lineEditSend->clear();
          }
          else
          {
              QMessageBox::warning(this, "Warning!", "Network error", QMessageBox::Yes);
          }