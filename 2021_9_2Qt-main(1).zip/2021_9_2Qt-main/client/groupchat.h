#ifndef GROUPCHAT_H
#define GROUPCHAT_H

#include <QWidget>
#include <QUdpSocket>

namespace Ui {
class groupChat;
}

class groupChat : public QWidget
{
    Q_OBJECT

    enum MsgType {Msg,UsrEnter,UsrLeft};

public:
    explicit groupChat(QWidget *parent,QString name);
    void sndMsg(MsgType type);
    void usrEnter(QString username);
    void usrLeft(QString usrname,QString time);
    QString getUsr();
    QString getMsg();
    ~groupChat();

private:
    Ui::groupChat *ui;
    QUdpSocket * udpSocket;
    qint16 port;
    QString uName;

    void ReceiveMessage();
};

#endif // GROUPCHAT_H
