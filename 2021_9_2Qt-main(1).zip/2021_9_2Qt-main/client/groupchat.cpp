#include "groupchat.h"
#include "ui_groupchat.h"
#include <userinfo.h>
#include <QWidget>
#include <QByteArray>
#include <QDataStream>
#include <QMessageBox>
#include <QHostAddress>
#include <QColorDialog>
#include <QColor>
#include <QFont>
#include <QComboBox>
#include <QPushButton>
#include <QDateTime>
#include <QUdpSocket>

extern userinfo user;
extern bool is_open_groupchat;
extern userinfo otheruser;
extern QString hostip;
extern int hosthost;

groupChat::groupChat(QWidget *parent,QString name) :
    QWidget(parent),
    ui(new Ui::groupChat)
{
    ui->setupUi(this);

    udpSocket = new QUdpSocket(this);

        uName = name;

        this->port = 9999;

        udpSocket->bind(this->port,QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint);

        //发送新用户进d入
        sndMsg(UsrEnter);

        //点击发送消息
        connect(ui->sendBtn,&QPushButton::clicked,[=]()
        {
           sndMsg(Msg);
        });

        //监听别人发送的消息
        connect(udpSocket,&QUdpSocket::readyRead,this,&groupChat::ReceiveMessage);

        //点击退出按钮 实现关闭窗口
        connect(ui->exitBtn,&QPushButton::clicked,[=]()
        {           this->close();    }
                );


        //辅助功能
    //    connect(ui->fontCbx,&QFontComboBox::currentFont,[=](const QFont &font){
    //        ui->msgTxtEdit->setCurrentFont(font);
    //        ui->msgTxtEdit->setFocus();
    //    });
        //字号
    //    void(QComboBox:: *cbxsingal)(const QString &text) = &QComboBox::currentIndexChanged();
    //    connect(ui->sizeCbx,&QComboBox::currentIndexChanged,[=](){

    //    });
        //字体颜色
        connect(ui->colorTBtn,&QToolButton::clicked,[=](){
           QColor color = QColorDialog::getColor(Qt::red);
           ui->msgTxtEdit->setTextColor(color);
        });

        connect(ui->clearTBtn,&QToolButton::clicked,[=](){
           ui->msgBrowser->clear();
        });
}

void groupChat::sndMsg(groupChat::MsgType type)
{
    //发送的消息分为三类
        //发送的数据做分段处理 第一段 类型 第二段 用户名 第三段 具体内容

        QByteArray array;

        QDataStream stream(&array,QIODevice::WriteOnly);

        stream<<type<<getUsr(); //第一段内容添加到流中 第二段 用户名

        switch(type){
        case Msg: //普通消息发送

            if(ui->msgTxtEdit->toPlainText()=="")
            {
                QMessageBox::warning(this,"警告","发送内容不能为空");
                return;
            }
            stream << getMsg();

            break;
        case UsrEnter: //新用户进入消息

            break;
        case UsrLeft: //用户离开消息

            break;
        default:

            break;
        }

        //书写报文 广播发送
        udpSocket->writeDatagram(array,QHostAddress::Broadcast,port);
}

void groupChat::usrEnter(QString username)
{
    //更新右侧的table
        bool isEmpty = ui->usrTblWidget->findItems(username,Qt::MatchExactly).isEmpty();
        if(isEmpty){
            QTableWidgetItem * usr = new QTableWidgetItem(username);

            //插入行
            ui->usrTblWidget->insertRow(0);
            ui->usrTblWidget->setItem(0,0,usr);

            //追加聊天记录
            ui->msgBrowser->setTextColor(Qt::green);
            ui->msgBrowser->append(QString("%1 上线了").arg(username));

            //在线用户
            ui->usrNumLbl->setText(QString("在线用户：%1人").arg(ui->usrTblWidget->rowCount()));

            //把自身的信息广播出去
            sndMsg(UsrEnter);

        }
}

void groupChat::usrLeft(QString usrname, QString time)
{
    //更新右侧tablewidget
        bool isEmpty=ui->usrTblWidget->findItems(usrname,Qt::MatchExactly).isEmpty();
        if(!isEmpty)
        {
            int row = ui->usrTblWidget->findItems(usrname,Qt::MatchExactly).first()->row();
            ui->usrTblWidget->removeRow(row);

            //追加聊天记录
            ui->msgBrowser->setTextColor(Qt::gray);
            ui->msgBrowser->append(QString("%1 于 %2 离开").arg(usrname).arg(time));
            //在线人数更新
            ui->usrNumLbl->setText(QString("在线人数: %1人").arg(ui->usrTblWidget->rowCount()));
        }
}

QString groupChat::getUsr()
{
    return user.name;
}

QString groupChat::getMsg()
{
    QString str = ui->msgTxtEdit->toHtml();
    //清空输入框
    ui->msgTxtEdit->clear();
    ui->msgTxtEdit->setFocus();
    return str;
}

groupChat::~groupChat()
{
    delete ui;
}

void groupChat::ReceiveMessage()
{
    //拿到数据报文
        //获取数据长度
        qint16 size = udpSocket->pendingDatagramSize();
        QByteArray array = QByteArray(10000,0);
        udpSocket->readDatagram(array.data(),size);
        //解析数据
        //第一段 类型 第二段 用户名 第三段 内容
        QDataStream stream(&array,QIODevice::ReadOnly);
        int msgType; //读取到类型

        QString usrName;
        QString msg;

        //获取当前时间
        QString time = QDateTime::currentDateTime().toString("yyyy-MM--dd hh:mm:ss");

        stream>>msgType;

        switch(msgType){
        case Msg: //普通聊天
            stream>>usrName>>msg;
            //追加聊天记录
            ui->msgBrowser->setTextColor(Qt::blue);
            ui->msgBrowser->append("["+usrName+"]"+time);
            ui->msgBrowser->append(msg);
            break;

        case UsrEnter:
            stream>>usrName;
            usrEnter(usrName);

            break;

        case UsrLeft:
            stream>>usrName;
            usrLeft(usrName,time);
        default:

            break;
        }
}
