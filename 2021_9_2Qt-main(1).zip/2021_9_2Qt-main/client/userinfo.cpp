#include "userinfo.h"

userinfo::userinfo()
{
    this->islogin = false;
    this->ip = "192.168.19.130";
    this->port = 8888;
}

userinfo user;
