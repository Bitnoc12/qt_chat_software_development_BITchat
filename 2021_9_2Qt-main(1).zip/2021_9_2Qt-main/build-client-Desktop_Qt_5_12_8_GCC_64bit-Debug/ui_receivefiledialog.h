/********************************************************************************
** Form generated from reading UI file 'receivefiledialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RECEIVEFILEDIALOG_H
#define UI_RECEIVEFILEDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_receivefiledialog
{
public:
    QLabel *label;
    QToolButton *toolButton;
    QWidget *widget;
    QLabel *label_message;
    QProgressBar *progressBar;

    void setupUi(QWidget *receivefiledialog)
    {
        if (receivefiledialog->objectName().isEmpty())
            receivefiledialog->setObjectName(QString::fromUtf8("receivefiledialog"));
        receivefiledialog->resize(441, 338);
        receivefiledialog->setMinimumSize(QSize(441, 338));
        receivefiledialog->setMaximumSize(QSize(441, 338));
        receivefiledialog->setStyleSheet(QString::fromUtf8("QWidget#widget\n"
"{\n"
"	\n"
"	background-image: url(:/Client/QT/icon/Background_5.jpg);\n"
"}"));
        label = new QLabel(receivefiledialog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(80, 30, 171, 51));
        label->setStyleSheet(QString::fromUtf8("font: 28pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"color: qlineargradient(spread:repeat, x1:0.72043, y1:0.732955, x2:1, y2:1, stop:0.134409 rgba(0, 0, 0, 255), stop:0.833333 rgba(96, 198, 66, 233));"));
        label->setAlignment(Qt::AlignCenter);
        toolButton = new QToolButton(receivefiledialog);
        toolButton->setObjectName(QString::fromUtf8("toolButton"));
        toolButton->setGeometry(QRect(310, 20, 90, 90));
        toolButton->setMinimumSize(QSize(90, 90));
        toolButton->setMaximumSize(QSize(90, 90));
        toolButton->setStyleSheet(QString::fromUtf8("border-style:none;"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Client/QT/icon/talk.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton->setIcon(icon);
        toolButton->setIconSize(QSize(75, 75));
        widget = new QWidget(receivefiledialog);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, 0, 441, 338));
        widget->setMinimumSize(QSize(441, 338));
        widget->setMaximumSize(QSize(441, 338));
        label_message = new QLabel(widget);
        label_message->setObjectName(QString::fromUtf8("label_message"));
        label_message->setGeometry(QRect(90, 130, 211, 41));
        label_message->setStyleSheet(QString::fromUtf8("color: rgb(170, 85, 0);\n"
"color: rgb(149, 0, 0);"));
        label_message->setAlignment(Qt::AlignCenter);
        progressBar = new QProgressBar(widget);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setGeometry(QRect(50, 230, 311, 31));
        progressBar->setValue(24);
        widget->raise();
        label->raise();
        toolButton->raise();

        retranslateUi(receivefiledialog);

        QMetaObject::connectSlotsByName(receivefiledialog);
    } // setupUi

    void retranslateUi(QWidget *receivefiledialog)
    {
        receivefiledialog->setWindowTitle(QApplication::translate("receivefiledialog", "ReceiveFile", nullptr));
        label->setText(QApplication::translate("receivefiledialog", "\346\216\245\346\224\266\346\226\207\344\273\266", nullptr));
        toolButton->setText(QApplication::translate("receivefiledialog", "...", nullptr));
        label_message->setText(QApplication::translate("receivefiledialog", "\347\255\211\345\276\205\344\270\216\345\217\221\351\200\201\347\253\257\350\277\236\346\216\245", nullptr));
    } // retranslateUi

};

namespace Ui {
    class receivefiledialog: public Ui_receivefiledialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RECEIVEFILEDIALOG_H
