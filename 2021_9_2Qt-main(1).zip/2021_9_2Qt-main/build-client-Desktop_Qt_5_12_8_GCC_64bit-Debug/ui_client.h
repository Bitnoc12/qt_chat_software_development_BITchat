/********************************************************************************
** Form generated from reading UI file 'client.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLIENT_H
#define UI_CLIENT_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_client
{
public:
    QWidget *centralwidget;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *lineEdit_username;
    QLineEdit *lineEdit_pwd;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label_username;
    QLabel *label_pwd;
    QWidget *verticalLayoutWidget_3;
    QVBoxLayout *verticalLayout_3;
    QToolButton *username;
    QToolButton *Pwd;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QToolButton *pushButton_register;
    QToolButton *pushButton_login;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QToolButton *toolButton;
    QWidget *widget;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *client)
    {
        if (client->objectName().isEmpty())
            client->setObjectName(QString::fromUtf8("client"));
        client->resize(554, 442);
        client->setMinimumSize(QSize(554, 442));
        client->setMaximumSize(QSize(554, 442));
        client->setStyleSheet(QString::fromUtf8(""));
        centralwidget = new QWidget(client);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setStyleSheet(QString::fromUtf8("QWidget#widget{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.971591, x2:0, y2:0, stop:0 rgba(177, 223, 150, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}"));
        verticalLayoutWidget_2 = new QWidget(centralwidget);
        verticalLayoutWidget_2->setObjectName(QString::fromUtf8("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(330, 110, 181, 121));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        lineEdit_username = new QLineEdit(verticalLayoutWidget_2);
        lineEdit_username->setObjectName(QString::fromUtf8("lineEdit_username"));
        lineEdit_username->setMinimumSize(QSize(0, 35));
        lineEdit_username->setMaximumSize(QSize(16777215, 35));
        lineEdit_username->setStyleSheet(QString::fromUtf8("background-color: rgba(255, 255, 255,0.5);\n"
"font: 75 14pt \"Comic Sans MS\";"));

        verticalLayout_2->addWidget(lineEdit_username);

        lineEdit_pwd = new QLineEdit(verticalLayoutWidget_2);
        lineEdit_pwd->setObjectName(QString::fromUtf8("lineEdit_pwd"));
        lineEdit_pwd->setMinimumSize(QSize(0, 35));
        lineEdit_pwd->setMaximumSize(QSize(16777215, 35));
        lineEdit_pwd->setStyleSheet(QString::fromUtf8("background-color: rgba(255, 255, 255,0.5);"));
        lineEdit_pwd->setEchoMode(QLineEdit::Password);

        verticalLayout_2->addWidget(lineEdit_pwd);

        verticalLayoutWidget = new QWidget(centralwidget);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(30, 110, 201, 121));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        verticalLayout->setContentsMargins(50, 0, 0, 0);
        label_username = new QLabel(verticalLayoutWidget);
        label_username->setObjectName(QString::fromUtf8("label_username"));
        label_username->setMinimumSize(QSize(150, 50));
        label_username->setMaximumSize(QSize(150, 50));
        label_username->setStyleSheet(QString::fromUtf8("font: 75 12pt \"Comic Sans MS\";\n"
""));
        label_username->setFrameShape(QFrame::Box);
        label_username->setFrameShadow(QFrame::Raised);
        label_username->setLineWidth(2);
        label_username->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_username);

        label_pwd = new QLabel(verticalLayoutWidget);
        label_pwd->setObjectName(QString::fromUtf8("label_pwd"));
        label_pwd->setMinimumSize(QSize(150, 50));
        label_pwd->setMaximumSize(QSize(150, 50));
        label_pwd->setStyleSheet(QString::fromUtf8("font: 75 12pt \"Comic Sans MS\";"));
        label_pwd->setFrameShape(QFrame::Box);
        label_pwd->setFrameShadow(QFrame::Raised);
        label_pwd->setLineWidth(2);
        label_pwd->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_pwd);

        verticalLayoutWidget_3 = new QWidget(centralwidget);
        verticalLayoutWidget_3->setObjectName(QString::fromUtf8("verticalLayoutWidget_3"));
        verticalLayoutWidget_3->setGeometry(QRect(270, 110, 42, 121));
        verticalLayout_3 = new QVBoxLayout(verticalLayoutWidget_3);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        username = new QToolButton(verticalLayoutWidget_3);
        username->setObjectName(QString::fromUtf8("username"));
        username->setMinimumSize(QSize(40, 40));
        username->setMaximumSize(QSize(40, 40));
        username->setStyleSheet(QString::fromUtf8("border-style:none"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Client/QT/icon/login_Account.png"), QSize(), QIcon::Normal, QIcon::Off);
        username->setIcon(icon);
        username->setIconSize(QSize(30, 30));

        verticalLayout_3->addWidget(username);

        Pwd = new QToolButton(verticalLayoutWidget_3);
        Pwd->setObjectName(QString::fromUtf8("Pwd"));
        Pwd->setMinimumSize(QSize(40, 40));
        Pwd->setMaximumSize(QSize(40, 40));
        Pwd->setStyleSheet(QString::fromUtf8("border-style:none"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/Client/QT/icon/Password.png"), QSize(), QIcon::Normal, QIcon::Off);
        Pwd->setIcon(icon1);
        Pwd->setIconSize(QSize(30, 30));

        verticalLayout_3->addWidget(Pwd);

        horizontalLayoutWidget = new QWidget(centralwidget);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(150, 260, 261, 108));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_register = new QToolButton(horizontalLayoutWidget);
        pushButton_register->setObjectName(QString::fromUtf8("pushButton_register"));
        pushButton_register->setStyleSheet(QString::fromUtf8("border-style:none;\n"
"font: 28pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/Client/QT/icon/Register.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_register->setIcon(icon2);
        pushButton_register->setIconSize(QSize(50, 50));
        pushButton_register->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);

        horizontalLayout->addWidget(pushButton_register);

        pushButton_login = new QToolButton(horizontalLayoutWidget);
        pushButton_login->setObjectName(QString::fromUtf8("pushButton_login"));
        pushButton_login->setStyleSheet(QString::fromUtf8("border-style:none;\n"
"font: 28pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/Client/QT/icon/Login.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_login->setIcon(icon3);
        pushButton_login->setIconSize(QSize(50, 50));
        pushButton_login->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);

        horizontalLayout->addWidget(pushButton_login);

        horizontalLayoutWidget_2 = new QWidget(centralwidget);
        horizontalLayoutWidget_2->setObjectName(QString::fromUtf8("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(80, 20, 341, 82));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(horizontalLayoutWidget_2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMinimumSize(QSize(0, 80));
        label->setMaximumSize(QSize(16777215, 80));
        label->setStyleSheet(QString::fromUtf8("font: 75 italic 28pt \"Comic Sans MS\";\n"
"color: qlineargradient(spread:repeat, x1:0.72043, y1:0.732955, x2:1, y2:1, stop:0.134409 rgba(0, 0, 0, 255), stop:0.833333 rgba(96, 198, 66, 233));"));
        label->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(label);

        toolButton = new QToolButton(horizontalLayoutWidget_2);
        toolButton->setObjectName(QString::fromUtf8("toolButton"));
        toolButton->setMinimumSize(QSize(80, 80));
        toolButton->setMaximumSize(QSize(80, 80));
        toolButton->setStyleSheet(QString::fromUtf8("border-style:none"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/Client/QT/icon/talk.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton->setIcon(icon4);
        toolButton->setIconSize(QSize(70, 70));

        horizontalLayout_2->addWidget(toolButton);

        widget = new QWidget(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, 0, 554, 399));
        client->setCentralWidget(centralwidget);
        widget->raise();
        verticalLayoutWidget_2->raise();
        verticalLayoutWidget->raise();
        verticalLayoutWidget_3->raise();
        horizontalLayoutWidget->raise();
        horizontalLayoutWidget_2->raise();
        menubar = new QMenuBar(client);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 554, 21));
        client->setMenuBar(menubar);
        statusbar = new QStatusBar(client);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        client->setStatusBar(statusbar);

        retranslateUi(client);

        QMetaObject::connectSlotsByName(client);
    } // setupUi

    void retranslateUi(QMainWindow *client)
    {
        client->setWindowTitle(QApplication::translate("client", "\345\276\256\347\273\277", nullptr));
        label_username->setText(QApplication::translate("client", "\347\224\250\346\210\267\345\220\215 Name", nullptr));
        label_pwd->setText(QApplication::translate("client", "\345\257\206\347\240\201 Password", nullptr));
        username->setText(QApplication::translate("client", "name", nullptr));
        Pwd->setText(QApplication::translate("client", "pwd ", nullptr));
        pushButton_register->setText(QApplication::translate("client", "\346\263\250\345\206\214", nullptr));
        pushButton_login->setText(QApplication::translate("client", "\347\231\273\345\275\225", nullptr));
        label->setText(QApplication::translate("client", "Welcome", nullptr));
        toolButton->setText(QApplication::translate("client", "...", nullptr));
    } // retranslateUi

};

namespace Ui {
    class client: public Ui_client {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLIENT_H
