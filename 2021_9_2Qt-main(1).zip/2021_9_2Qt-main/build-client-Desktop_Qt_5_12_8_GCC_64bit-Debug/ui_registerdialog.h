/********************************************************************************
** Form generated from reading UI file 'registerdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTERDIALOG_H
#define UI_REGISTERDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_registerdialog
{
public:
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label_name;
    QLabel *label_passwordone;
    QLabel *label_passwordtwo;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *lineEdit_name;
    QLineEdit *lineEdit_passwordone;
    QLineEdit *lineEdit_passwordtwo;
    QWidget *verticalLayoutWidget_3;
    QVBoxLayout *verticalLayout_3;
    QToolButton *toolButton;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QToolButton *toolButton_2;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QToolButton *pushButton_back;
    QToolButton *pushButton_register;
    QWidget *widget;

    void setupUi(QWidget *registerdialog)
    {
        if (registerdialog->objectName().isEmpty())
            registerdialog->setObjectName(QString::fromUtf8("registerdialog"));
        registerdialog->resize(513, 423);
        registerdialog->setMinimumSize(QSize(513, 423));
        registerdialog->setMaximumSize(QSize(513, 423));
        registerdialog->setStyleSheet(QString::fromUtf8("QWidget#widget\n"
"{\n"
"	\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0.971591, x2:0, y2:0, stop:0 rgba(177, 223, 150, 255), stop:1 rgba(255, 255, 255, 255));\n"
"}"));
        verticalLayoutWidget = new QWidget(registerdialog);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(40, 100, 161, 164));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_name = new QLabel(verticalLayoutWidget);
        label_name->setObjectName(QString::fromUtf8("label_name"));
        label_name->setMinimumSize(QSize(0, 50));
        label_name->setMaximumSize(QSize(16777215, 50));
        label_name->setStyleSheet(QString::fromUtf8("font: 75 12pt \"Comic Sans MS\";"));
        label_name->setFrameShape(QFrame::Box);
        label_name->setFrameShadow(QFrame::Raised);
        label_name->setLineWidth(2);
        label_name->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_name);

        label_passwordone = new QLabel(verticalLayoutWidget);
        label_passwordone->setObjectName(QString::fromUtf8("label_passwordone"));
        label_passwordone->setMinimumSize(QSize(0, 50));
        label_passwordone->setMaximumSize(QSize(16777215, 50));
        label_passwordone->setStyleSheet(QString::fromUtf8("font: 75 12pt \"Comic Sans MS\";"));
        label_passwordone->setFrameShape(QFrame::Box);
        label_passwordone->setFrameShadow(QFrame::Raised);
        label_passwordone->setLineWidth(2);
        label_passwordone->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_passwordone);

        label_passwordtwo = new QLabel(verticalLayoutWidget);
        label_passwordtwo->setObjectName(QString::fromUtf8("label_passwordtwo"));
        label_passwordtwo->setMinimumSize(QSize(0, 50));
        label_passwordtwo->setMaximumSize(QSize(16777215, 50));
        label_passwordtwo->setStyleSheet(QString::fromUtf8("font: 75 12pt \"Comic Sans MS\";"));
        label_passwordtwo->setFrameShape(QFrame::Box);
        label_passwordtwo->setFrameShadow(QFrame::Raised);
        label_passwordtwo->setLineWidth(2);
        label_passwordtwo->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_passwordtwo);

        verticalLayoutWidget_2 = new QWidget(registerdialog);
        verticalLayoutWidget_2->setObjectName(QString::fromUtf8("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(270, 100, 221, 161));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        lineEdit_name = new QLineEdit(verticalLayoutWidget_2);
        lineEdit_name->setObjectName(QString::fromUtf8("lineEdit_name"));
        lineEdit_name->setMinimumSize(QSize(215, 40));
        lineEdit_name->setMaximumSize(QSize(215, 40));
        lineEdit_name->setStyleSheet(QString::fromUtf8("font: 75 14pt \"Comic Sans MS\";"));

        verticalLayout_2->addWidget(lineEdit_name);

        lineEdit_passwordone = new QLineEdit(verticalLayoutWidget_2);
        lineEdit_passwordone->setObjectName(QString::fromUtf8("lineEdit_passwordone"));
        lineEdit_passwordone->setMinimumSize(QSize(215, 40));
        lineEdit_passwordone->setMaximumSize(QSize(215, 40));
        lineEdit_passwordone->setStyleSheet(QString::fromUtf8(""));
        lineEdit_passwordone->setEchoMode(QLineEdit::Password);

        verticalLayout_2->addWidget(lineEdit_passwordone);

        lineEdit_passwordtwo = new QLineEdit(verticalLayoutWidget_2);
        lineEdit_passwordtwo->setObjectName(QString::fromUtf8("lineEdit_passwordtwo"));
        lineEdit_passwordtwo->setMinimumSize(QSize(215, 40));
        lineEdit_passwordtwo->setMaximumSize(QSize(215, 40));
        lineEdit_passwordtwo->setStyleSheet(QString::fromUtf8(""));
        lineEdit_passwordtwo->setEchoMode(QLineEdit::Password);

        verticalLayout_2->addWidget(lineEdit_passwordtwo);

        verticalLayoutWidget_3 = new QWidget(registerdialog);
        verticalLayoutWidget_3->setObjectName(QString::fromUtf8("verticalLayoutWidget_3"));
        verticalLayoutWidget_3->setGeometry(QRect(220, 100, 52, 164));
        verticalLayout_3 = new QVBoxLayout(verticalLayoutWidget_3);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        toolButton = new QToolButton(verticalLayoutWidget_3);
        toolButton->setObjectName(QString::fromUtf8("toolButton"));
        toolButton->setMinimumSize(QSize(50, 50));
        toolButton->setMaximumSize(QSize(50, 50));
        toolButton->setStyleSheet(QString::fromUtf8("border-style:none;"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Client/QT/icon/name_lightgreen.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton->setIcon(icon);
        toolButton->setIconSize(QSize(40, 40));

        verticalLayout_3->addWidget(toolButton);

        pushButton = new QPushButton(verticalLayoutWidget_3);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setMinimumSize(QSize(50, 50));
        pushButton->setMaximumSize(QSize(50, 50));
        pushButton->setStyleSheet(QString::fromUtf8("border-style:none;"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/Client/QT/icon/password_green.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton->setIcon(icon1);
        pushButton->setIconSize(QSize(30, 30));

        verticalLayout_3->addWidget(pushButton);

        pushButton_2 = new QPushButton(verticalLayoutWidget_3);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setMinimumSize(QSize(50, 50));
        pushButton_2->setMaximumSize(QSize(50, 50));
        pushButton_2->setStyleSheet(QString::fromUtf8("border-style:none;"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/Client/QT/icon/confirPwd_green.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_2->setIcon(icon2);
        pushButton_2->setIconSize(QSize(40, 40));

        verticalLayout_3->addWidget(pushButton_2);

        horizontalLayoutWidget_2 = new QWidget(registerdialog);
        horizontalLayoutWidget_2->setObjectName(QString::fromUtf8("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(70, 10, 351, 80));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(horizontalLayoutWidget_2);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMinimumSize(QSize(175, 65));
        label->setMaximumSize(QSize(175, 65));
        label->setStyleSheet(QString::fromUtf8("font: 75 italic 30pt \"Comic Sans MS\";\n"
"color: qlineargradient(spread:repeat, x1:0.72043, y1:0.732955, x2:1, y2:1, stop:0.134409 rgba(0, 0, 0, 255), stop:0.833333 rgba(96, 198, 66, 233));"));
        label->setFrameShape(QFrame::NoFrame);
        label->setFrameShadow(QFrame::Plain);
        label->setLineWidth(2);
        label->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(label);

        toolButton_2 = new QToolButton(horizontalLayoutWidget_2);
        toolButton_2->setObjectName(QString::fromUtf8("toolButton_2"));
        toolButton_2->setMinimumSize(QSize(65, 65));
        toolButton_2->setMaximumSize(QSize(65, 65));
        toolButton_2->setStyleSheet(QString::fromUtf8("border-style:none;"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/Client/QT/icon/talk.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton_2->setIcon(icon3);
        toolButton_2->setIconSize(QSize(50, 50));

        horizontalLayout_2->addWidget(toolButton_2);

        horizontalLayoutWidget = new QWidget(registerdialog);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(100, 280, 351, 101));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_back = new QToolButton(horizontalLayoutWidget);
        pushButton_back->setObjectName(QString::fromUtf8("pushButton_back"));
        pushButton_back->setMinimumSize(QSize(110, 85));
        pushButton_back->setMaximumSize(QSize(110, 85));
        pushButton_back->setStyleSheet(QString::fromUtf8("#pushButton_back:hover\n"
"\n"
"{\n"
"	border-style:none;\n"
"    font: 25pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgb(85, 170, 0);\n"
"}\n"
"#pushButton_back:!hover\n"
"{\n"
"	border-style:none;\n"
"    font: 25pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgb(0, 0, 0);\n"
"}"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/Client/QT/icon/Back_purple.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_back->setIcon(icon4);
        pushButton_back->setIconSize(QSize(50, 50));
        pushButton_back->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);

        horizontalLayout->addWidget(pushButton_back);

        pushButton_register = new QToolButton(horizontalLayoutWidget);
        pushButton_register->setObjectName(QString::fromUtf8("pushButton_register"));
        pushButton_register->setMinimumSize(QSize(150, 85));
        pushButton_register->setMaximumSize(QSize(150, 85));
        pushButton_register->setStyleSheet(QString::fromUtf8("#pushButton_register:hover\n"
"{\n"
"	border-style:none;\n"
"    font: 25pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgb(74, 255, 119);\n"
"}\n"
"#pushButton_register:!hover\n"
"{\n"
"	border-style:none;\n"
"    font: 25pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgb(0, 0, 0);\n"
"}"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/Client/QT/icon/go.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_register->setIcon(icon5);
        pushButton_register->setIconSize(QSize(50, 50));
        pushButton_register->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);

        horizontalLayout->addWidget(pushButton_register);

        widget = new QWidget(registerdialog);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, 0, 513, 423));
        widget->raise();
        verticalLayoutWidget->raise();
        verticalLayoutWidget_2->raise();
        verticalLayoutWidget_3->raise();
        horizontalLayoutWidget_2->raise();
        horizontalLayoutWidget->raise();

        retranslateUi(registerdialog);

        QMetaObject::connectSlotsByName(registerdialog);
    } // setupUi

    void retranslateUi(QWidget *registerdialog)
    {
        registerdialog->setWindowTitle(QApplication::translate("registerdialog", "Register", nullptr));
        label_name->setText(QApplication::translate("registerdialog", "\346\230\265\347\247\260 Name", nullptr));
        label_passwordone->setText(QApplication::translate("registerdialog", "\345\257\206\347\240\201 Password", nullptr));
        label_passwordtwo->setText(QApplication::translate("registerdialog", "\347\241\256\350\256\244\345\257\206\347\240\201 Password", nullptr));
        toolButton->setText(QApplication::translate("registerdialog", "...", nullptr));
        pushButton->setText(QString());
        pushButton_2->setText(QString());
        label->setText(QApplication::translate("registerdialog", "Register", nullptr));
        toolButton_2->setText(QApplication::translate("registerdialog", "...", nullptr));
        pushButton_back->setText(QApplication::translate("registerdialog", "\350\277\224\345\233\236", nullptr));
        pushButton_register->setText(QApplication::translate("registerdialog", "\347\241\256\350\256\244\346\263\250\345\206\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class registerdialog: public Ui_registerdialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTERDIALOG_H
