/********************************************************************************
** Form generated from reading UI file 'home.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOME_H
#define UI_HOME_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_home
{
public:
    QLabel *label;
    QListWidget *listWidget;
    QLabel *label_3;
    QToolButton *toolButton;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QToolButton *pushButton_receivefile;
    QToolButton *pushButton_sendfile;
    QToolButton *pushButton_quit;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_2;
    QLabel *label_4;
    QWidget *widget;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QVBoxLayout *verticalLayout;
    QLabel *label_6;
    QLabel *label_7;
    QLineEdit *lineEdit_sendname;
    QToolButton *pushButton_sendmessage;
    QToolButton *pushButton_fresh;
    QToolButton *pushButton_startchat;
    QWidget *horizontalLayoutWidget_3;
    QHBoxLayout *horizontalLayout_3;
    QToolButton *pushButton_addpeople;
    QPushButton *pushButton_group_chat;
    QToolButton *pushButton_deletepeople;

    void setupUi(QWidget *home)
    {
        if (home->objectName().isEmpty())
            home->setObjectName(QString::fromUtf8("home"));
        home->resize(848, 452);
        home->setMinimumSize(QSize(848, 452));
        home->setMaximumSize(QSize(661, 451));
        home->setStyleSheet(QString::fromUtf8("QWidget#widget\n"
"{\n"
"	\n"
"	background-image: url(:/Client/QT/icon/Background_2.jpg);\n"
"\n"
"}"));
        label = new QLabel(home);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(170, 20, 191, 41));
        label->setStyleSheet(QString::fromUtf8("font: 20pt \"\351\273\221\344\275\223\";\n"
"color: rgb(0, 170, 0);"));
        label->setAlignment(Qt::AlignCenter);
        listWidget = new QListWidget(home);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        listWidget->setGeometry(QRect(20, 90, 341, 201));
        listWidget->setStyleSheet(QString::fromUtf8("font: 75 italic 12pt \"Comic Sans MS\";\n"
"background-color: rgba(255, 255, 255,0.7);"));
        label_3 = new QLabel(home);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 50, 131, 31));
        label_3->setStyleSheet(QString::fromUtf8("font: 18pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";"));
        label_3->setAlignment(Qt::AlignCenter);
        toolButton = new QToolButton(home);
        toolButton->setObjectName(QString::fromUtf8("toolButton"));
        toolButton->setGeometry(QRect(470, 10, 100, 100));
        toolButton->setMinimumSize(QSize(100, 100));
        toolButton->setMaximumSize(QSize(100, 100));
        toolButton->setStyleSheet(QString::fromUtf8("border-style:none;"));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Client/QT/icon/talk.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton->setIcon(icon);
        toolButton->setIconSize(QSize(80, 80));
        horizontalLayoutWidget = new QWidget(home);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(370, 320, 271, 91));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_receivefile = new QToolButton(horizontalLayoutWidget);
        pushButton_receivefile->setObjectName(QString::fromUtf8("pushButton_receivefile"));
        pushButton_receivefile->setMinimumSize(QSize(80, 80));
        pushButton_receivefile->setMaximumSize(QSize(80, 80));
        pushButton_receivefile->setStyleSheet(QString::fromUtf8("#pushButton_receivefile:hover\n"
"{\n"
"	border-style:none;\n"
"	font: 12pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgba(0, 0, 0, 1);\n"
"}\n"
"\n"
"#pushButton_receivefile:!hover\n"
"{\n"
"	border-style:none;\n"
"	font: 75 12pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgba(0, 0, 0, 0);\n"
"}\n"
""));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/Client/QT/icon/File.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_receivefile->setIcon(icon1);
        pushButton_receivefile->setIconSize(QSize(50, 50));
        pushButton_receivefile->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        pushButton_receivefile->setAutoRaise(false);
        pushButton_receivefile->setArrowType(Qt::NoArrow);

        horizontalLayout->addWidget(pushButton_receivefile);

        pushButton_sendfile = new QToolButton(horizontalLayoutWidget);
        pushButton_sendfile->setObjectName(QString::fromUtf8("pushButton_sendfile"));
        pushButton_sendfile->setMinimumSize(QSize(80, 80));
        pushButton_sendfile->setMaximumSize(QSize(80, 80));
        pushButton_sendfile->setStyleSheet(QString::fromUtf8("#pushButton_sendfile:hover\n"
"{\n"
"	border-style:none;\n"
"	font: 12pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgba(0, 0, 0, 1);\n"
"}\n"
"\n"
"#pushButton_sendfile:!hover\n"
"{\n"
"	border-style:none;\n"
"	font: 75 12pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgba(0, 0, 0, 0);\n"
"}\n"
""));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/Client/QT/icon/SendFile.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_sendfile->setIcon(icon2);
        pushButton_sendfile->setIconSize(QSize(50, 50));
        pushButton_sendfile->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);

        horizontalLayout->addWidget(pushButton_sendfile);

        pushButton_quit = new QToolButton(horizontalLayoutWidget);
        pushButton_quit->setObjectName(QString::fromUtf8("pushButton_quit"));
        pushButton_quit->setMinimumSize(QSize(80, 80));
        pushButton_quit->setMaximumSize(QSize(80, 80));
        pushButton_quit->setStyleSheet(QString::fromUtf8("#pushButton_quit:hover\n"
"{\n"
"	border-style:none;\n"
"	font: 12pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgba(0, 0, 0, 1);\n"
"}\n"
"\n"
"#pushButton_quit:!hover\n"
"{\n"
"	border-style:none;\n"
"	font: 75 12pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgba(0, 0, 0, 0);\n"
"}\n"
""));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/Client/QT/icon/LoginOut_blue.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_quit->setIcon(icon3);
        pushButton_quit->setIconSize(QSize(50, 50));
        pushButton_quit->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);

        horizontalLayout->addWidget(pushButton_quit);

        verticalLayoutWidget = new QWidget(home);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(510, 110, 132, 80));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(verticalLayoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setMinimumSize(QSize(130, 30));
        label_2->setMaximumSize(QSize(130, 30));
        label_2->setStyleSheet(QString::fromUtf8("font: 75 16pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: rgb(66, 91, 255);"));
        label_2->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_2);

        label_4 = new QLabel(verticalLayoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setMinimumSize(QSize(120, 30));
        label_4->setMaximumSize(QSize(130, 30));
        label_4->setStyleSheet(QString::fromUtf8("font: 75 16pt \"\345\276\256\350\275\257\351\233\205\351\273\221\";\n"
"color: rgb(66, 91, 255);"));
        label_4->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_4);

        widget = new QWidget(home);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, 0, 691, 501));
        horizontalLayoutWidget_2 = new QWidget(widget);
        horizontalLayoutWidget_2->setObjectName(QString::fromUtf8("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(80, 320, 271, 106));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_6 = new QLabel(horizontalLayoutWidget_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setStyleSheet(QString::fromUtf8("font: 15pt \"\345\215\216\346\226\207\346\245\267\344\275\223\";"));
        label_6->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_6);

        label_7 = new QLabel(horizontalLayoutWidget_2);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setStyleSheet(QString::fromUtf8("font: 15pt \"\345\215\216\346\226\207\346\245\267\344\275\223\";"));
        label_7->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_7);

        lineEdit_sendname = new QLineEdit(horizontalLayoutWidget_2);
        lineEdit_sendname->setObjectName(QString::fromUtf8("lineEdit_sendname"));
        lineEdit_sendname->setMinimumSize(QSize(125, 30));
        lineEdit_sendname->setMaximumSize(QSize(125, 30));
        lineEdit_sendname->setStyleSheet(QString::fromUtf8("background-color: rgba(255, 255, 255,0.5);"));

        verticalLayout->addWidget(lineEdit_sendname);


        horizontalLayout_2->addLayout(verticalLayout);

        pushButton_sendmessage = new QToolButton(horizontalLayoutWidget_2);
        pushButton_sendmessage->setObjectName(QString::fromUtf8("pushButton_sendmessage"));
        pushButton_sendmessage->setMinimumSize(QSize(80, 80));
        pushButton_sendmessage->setMaximumSize(QSize(80, 80));
        pushButton_sendmessage->setStyleSheet(QString::fromUtf8("#pushButton_sendmessage:hover\n"
"{\n"
"	border-style:none;\n"
"	font: 12pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgba(0, 0, 0, 1);\n"
"}\n"
"\n"
"#pushButton_sendmessage:!hover\n"
"{\n"
"	border-style:none;\n"
"	font: 75 12pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgba(0, 0, 0, 0);\n"
"}\n"
""));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/Client/QT/icon/Chat.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_sendmessage->setIcon(icon4);
        pushButton_sendmessage->setIconSize(QSize(50, 50));
        pushButton_sendmessage->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);

        horizontalLayout_2->addWidget(pushButton_sendmessage);

        pushButton_fresh = new QToolButton(widget);
        pushButton_fresh->setObjectName(QString::fromUtf8("pushButton_fresh"));
        pushButton_fresh->setGeometry(QRect(10, 320, 60, 60));
        pushButton_fresh->setMinimumSize(QSize(60, 60));
        pushButton_fresh->setMaximumSize(QSize(60, 60));
        pushButton_fresh->setStyleSheet(QString::fromUtf8("#pushButton_fresh:hover\n"
"{\n"
"	border-style:none;\n"
"	font: 12pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgba(0, 0, 0, 1);\n"
"}\n"
"\n"
"#pushButton_fresh:!hover\n"
"{\n"
"	border-style:none;\n"
"	font: 75 12pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgba(0, 0, 0, 0);\n"
"}\n"
""));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/Client/QT/icon/Refresh.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_fresh->setIcon(icon5);
        pushButton_fresh->setIconSize(QSize(35, 35));
        pushButton_fresh->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        pushButton_startchat = new QToolButton(widget);
        pushButton_startchat->setObjectName(QString::fromUtf8("pushButton_startchat"));
        pushButton_startchat->setGeometry(QRect(370, 120, 80, 80));
        pushButton_startchat->setMinimumSize(QSize(80, 80));
        pushButton_startchat->setMaximumSize(QSize(80, 80));
        pushButton_startchat->setStyleSheet(QString::fromUtf8("#pushButton_startchat:hover\n"
"{\n"
"	border-style:none;\n"
"	font: 12pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgba(0, 0, 0, 1);\n"
"}\n"
"\n"
"#pushButton_startchat:!hover\n"
"{\n"
"	border-style:none;\n"
"	font: 75 12pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgba(0, 0, 0, 0);\n"
"}\n"
""));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/Client/QT/icon/Chat_icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_startchat->setIcon(icon6);
        pushButton_startchat->setIconSize(QSize(50, 50));
        pushButton_startchat->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        horizontalLayoutWidget_3 = new QWidget(widget);
        horizontalLayoutWidget_3->setObjectName(QString::fromUtf8("horizontalLayoutWidget_3"));
        horizontalLayoutWidget_3->setGeometry(QRect(370, 210, 271, 99));
        horizontalLayout_3 = new QHBoxLayout(horizontalLayoutWidget_3);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        pushButton_addpeople = new QToolButton(horizontalLayoutWidget_3);
        pushButton_addpeople->setObjectName(QString::fromUtf8("pushButton_addpeople"));
        pushButton_addpeople->setMinimumSize(QSize(80, 80));
        pushButton_addpeople->setMaximumSize(QSize(80, 80));
        pushButton_addpeople->setStyleSheet(QString::fromUtf8("#pushButton_addpeople:hover\n"
"{\n"
"	border-style:none;\n"
"	font: 12pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgba(0, 0, 0, 1);\n"
"}\n"
"\n"
"#pushButton_addpeople:!hover\n"
"{\n"
"	border-style:none;\n"
"	font: 75 12pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgba(0, 0, 0, 0);\n"
"}\n"
""));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/Client/QT/icon/AddAccount.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_addpeople->setIcon(icon7);
        pushButton_addpeople->setIconSize(QSize(50, 50));
        pushButton_addpeople->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);

        horizontalLayout_3->addWidget(pushButton_addpeople);

        pushButton_group_chat = new QPushButton(horizontalLayoutWidget_3);
        pushButton_group_chat->setObjectName(QString::fromUtf8("pushButton_group_chat"));

        horizontalLayout_3->addWidget(pushButton_group_chat);

        pushButton_deletepeople = new QToolButton(horizontalLayoutWidget_3);
        pushButton_deletepeople->setObjectName(QString::fromUtf8("pushButton_deletepeople"));
        pushButton_deletepeople->setMinimumSize(QSize(80, 80));
        pushButton_deletepeople->setMaximumSize(QSize(80, 80));
        pushButton_deletepeople->setStyleSheet(QString::fromUtf8("#pushButton_deletepeople:hover\n"
"{\n"
"	border-style:none;\n"
"	font: 12pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgba(0, 0, 0, 1);\n"
"}\n"
"\n"
"#pushButton_deletepeople:!hover\n"
"{\n"
"	border-style:none;\n"
"	font: 75 12pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"	color: rgba(0, 0, 0, 0);\n"
"}\n"
""));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":/Client/QT/icon/Delete.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_deletepeople->setIcon(icon8);
        pushButton_deletepeople->setIconSize(QSize(50, 50));
        pushButton_deletepeople->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);

        horizontalLayout_3->addWidget(pushButton_deletepeople);

        widget->raise();
        label->raise();
        listWidget->raise();
        label_3->raise();
        toolButton->raise();
        horizontalLayoutWidget->raise();
        verticalLayoutWidget->raise();

        retranslateUi(home);

        QMetaObject::connectSlotsByName(home);
    } // setupUi

    void retranslateUi(QWidget *home)
    {
        home->setWindowTitle(QApplication::translate("home", "Function", nullptr));
        label->setText(QApplication::translate("home", "\346\202\250\345\245\275\357\274\214", nullptr));
        label_3->setText(QApplication::translate("home", "\350\201\224\347\263\273\344\272\272\345\210\227\350\241\250", nullptr));
        toolButton->setText(QApplication::translate("home", "...", nullptr));
        pushButton_receivefile->setText(QApplication::translate("home", "\346\216\245\346\224\266\346\226\207\344\273\266", nullptr));
        pushButton_sendfile->setText(QApplication::translate("home", "\345\217\221\351\200\201\346\226\207\344\273\266", nullptr));
        pushButton_quit->setText(QApplication::translate("home", "\351\200\200\345\207\272\347\231\273\345\275\225", nullptr));
        label_2->setText(QApplication::translate("home", "\346\224\266\345\217\221\346\226\207\344\273\266", nullptr));
        label_4->setText(QApplication::translate("home", "\344\273\205\350\201\224\347\263\273\344\272\272\345\212\237\350\203\275", nullptr));
        label_6->setText(QApplication::translate("home", "\350\276\223\345\205\245\345\257\271\346\226\271\346\230\265\347\247\260", nullptr));
        label_7->setText(QApplication::translate("home", "\345\274\200\345\247\213\345\257\271\350\257\235", nullptr));
        pushButton_sendmessage->setText(QApplication::translate("home", "\350\201\212\345\244\251", nullptr));
        pushButton_fresh->setText(QApplication::translate("home", "\345\210\267\346\226\260", nullptr));
        pushButton_startchat->setText(QApplication::translate("home", "\345\274\200\345\247\213\345\257\271\350\257\235", nullptr));
        pushButton_addpeople->setText(QApplication::translate("home", "\346\267\273\345\212\240\350\201\224\347\263\273\344\272\272", nullptr));
        pushButton_group_chat->setText(QApplication::translate("home", "\347\276\244\350\201\212", nullptr));
        pushButton_deletepeople->setText(QApplication::translate("home", "\345\210\240\351\231\244\350\201\224\347\263\273\344\272\272", nullptr));
    } // retranslateUi

};

namespace Ui {
    class home: public Ui_home {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOME_H
