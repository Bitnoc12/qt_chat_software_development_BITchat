/********************************************************************************
** Form generated from reading UI file 'sendfiledialog.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SENDFILEDIALOG_H
#define UI_SENDFILEDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_sendfiledialog
{
public:
    QLabel *label_title;
    QLabel *label_message;
    QLabel *label_people;
    QToolButton *pushButton_selectfile;
    QToolButton *pushButton_sendfile;
    QToolButton *toolButton;
    QWidget *widget;

    void setupUi(QWidget *sendfiledialog)
    {
        if (sendfiledialog->objectName().isEmpty())
            sendfiledialog->setObjectName(QString::fromUtf8("sendfiledialog"));
        sendfiledialog->resize(455, 340);
        sendfiledialog->setMinimumSize(QSize(455, 340));
        sendfiledialog->setMaximumSize(QSize(455, 340));
        sendfiledialog->setStyleSheet(QString::fromUtf8("QWidget#widget\n"
"{\n"
"	\n"
"	background-image: url(:/Client/QT/icon/Background_2.jpg);\n"
"\n"
"}"));
        label_title = new QLabel(sendfiledialog);
        label_title->setObjectName(QString::fromUtf8("label_title"));
        label_title->setGeometry(QRect(90, 30, 171, 41));
        label_title->setStyleSheet(QString::fromUtf8("font: 28pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"color: qlineargradient(spread:repeat, x1:0.72043, y1:0.732955, x2:1, y2:1, stop:0.134409 rgba(0, 0, 0, 255), stop:0.833333 rgba(96, 198, 66, 233));"));
        label_title->setAlignment(Qt::AlignCenter);
        label_message = new QLabel(sendfiledialog);
        label_message->setObjectName(QString::fromUtf8("label_message"));
        label_message->setGeometry(QRect(50, 120, 351, 51));
        label_message->setStyleSheet(QString::fromUtf8("font: 75 12pt \"Comic Sans MS\";\n"
"color: rgb(255, 0, 0);"));
        label_message->setAlignment(Qt::AlignCenter);
        label_people = new QLabel(sendfiledialog);
        label_people->setObjectName(QString::fromUtf8("label_people"));
        label_people->setGeometry(QRect(60, 70, 171, 51));
        label_people->setStyleSheet(QString::fromUtf8("font: 75 14pt \"Comic Sans MS\";\n"
"color: rgb(170, 255, 255);"));
        label_people->setAlignment(Qt::AlignCenter);
        pushButton_selectfile = new QToolButton(sendfiledialog);
        pushButton_selectfile->setObjectName(QString::fromUtf8("pushButton_selectfile"));
        pushButton_selectfile->setGeometry(QRect(50, 180, 120, 120));
        pushButton_selectfile->setMinimumSize(QSize(120, 120));
        pushButton_selectfile->setMaximumSize(QSize(120, 120));
        pushButton_selectfile->setStyleSheet(QString::fromUtf8("\n"
"	border-style:none;\n"
"	font: 18pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"\n"
"\n"
""));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Client/QT/icon/SlectFile.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_selectfile->setIcon(icon);
        pushButton_selectfile->setIconSize(QSize(75, 75));
        pushButton_selectfile->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        pushButton_sendfile = new QToolButton(sendfiledialog);
        pushButton_sendfile->setObjectName(QString::fromUtf8("pushButton_sendfile"));
        pushButton_sendfile->setGeometry(QRect(240, 180, 120, 120));
        pushButton_sendfile->setMinimumSize(QSize(120, 120));
        pushButton_sendfile->setMaximumSize(QSize(120, 120));
        pushButton_sendfile->setStyleSheet(QString::fromUtf8("\n"
"	border-style:none;\n"
"	font: 18pt \"\345\215\216\346\226\207\351\232\266\344\271\246\";\n"
"\n"
"\n"
""));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/Client/QT/icon/SendFile_blue.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_sendfile->setIcon(icon1);
        pushButton_sendfile->setIconSize(QSize(75, 75));
        pushButton_sendfile->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        toolButton = new QToolButton(sendfiledialog);
        toolButton->setObjectName(QString::fromUtf8("toolButton"));
        toolButton->setGeometry(QRect(290, 10, 90, 90));
        toolButton->setMinimumSize(QSize(90, 90));
        toolButton->setMaximumSize(QSize(90, 90));
        toolButton->setStyleSheet(QString::fromUtf8("border-style:none;\n"
""));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/Client/QT/icon/talk.png"), QSize(), QIcon::Normal, QIcon::Off);
        toolButton->setIcon(icon2);
        toolButton->setIconSize(QSize(75, 75));
        widget = new QWidget(sendfiledialog);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(0, 0, 455, 340));
        widget->setMinimumSize(QSize(455, 340));
        widget->setMaximumSize(QSize(455, 340));
        widget->raise();
        label_title->raise();
        label_message->raise();
        label_people->raise();
        pushButton_selectfile->raise();
        pushButton_sendfile->raise();
        toolButton->raise();

        retranslateUi(sendfiledialog);

        QMetaObject::connectSlotsByName(sendfiledialog);
    } // setupUi

    void retranslateUi(QWidget *sendfiledialog)
    {
        sendfiledialog->setWindowTitle(QApplication::translate("sendfiledialog", "SendFile", nullptr));
        label_title->setText(QApplication::translate("sendfiledialog", "\345\217\221\351\200\201\346\226\207\344\273\266", nullptr));
        label_message->setText(QApplication::translate("sendfiledialog", "\350\257\267\351\200\211\346\213\251\346\226\207\344\273\266", nullptr));
        label_people->setText(QApplication::translate("sendfiledialog", "TextLabel", nullptr));
        pushButton_selectfile->setText(QApplication::translate("sendfiledialog", "\351\200\211\346\213\251\346\226\207\344\273\266", nullptr));
        pushButton_sendfile->setText(QApplication::translate("sendfiledialog", "\345\217\221\351\200\201\346\226\207\344\273\266", nullptr));
        toolButton->setText(QApplication::translate("sendfiledialog", "...", nullptr));
    } // retranslateUi

};

namespace Ui {
    class sendfiledialog: public Ui_sendfiledialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SENDFILEDIALOG_H
