/********************************************************************************
** Form generated from reading UI file 'groupchat.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GROUPCHAT_H
#define UI_GROUPCHAT_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFontComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_groupChat
{
public:
    QVBoxLayout *verticalLayout_5;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_4;
    QFrame *frame_3;
    QVBoxLayout *verticalLayout_4;
    QTextBrowser *msgBrowser;
    QFrame *frame_4;
    QHBoxLayout *horizontalLayout_5;
    QFontComboBox *fontCbx;
    QComboBox *sizeCbx;
    QToolButton *boldTBtn;
    QToolButton *italicTBtn;
    QToolButton *underlineTBtn;
    QToolButton *colorTBtn;
    QToolButton *saveTBtn;
    QToolButton *clearTBtn;
    QTextEdit *msgTxtEdit;
    QTableWidget *usrTblWidget;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *sendBtn;
    QSpacerItem *horizontalSpacer_3;
    QLabel *usrNumLbl;
    QSpacerItem *horizontalSpacer_4;
    QPushButton *exitBtn;

    void setupUi(QWidget *groupChat)
    {
        if (groupChat->objectName().isEmpty())
            groupChat->setObjectName(QString::fromUtf8("groupChat"));
        groupChat->resize(683, 455);
        verticalLayout_5 = new QVBoxLayout(groupChat);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        frame_3 = new QFrame(groupChat);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setFrameShape(QFrame::Box);
        verticalLayout_4 = new QVBoxLayout(frame_3);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        msgBrowser = new QTextBrowser(frame_3);
        msgBrowser->setObjectName(QString::fromUtf8("msgBrowser"));

        verticalLayout_4->addWidget(msgBrowser);

        frame_4 = new QFrame(frame_3);
        frame_4->setObjectName(QString::fromUtf8("frame_4"));
        frame_4->setFrameShape(QFrame::Box);
        horizontalLayout_5 = new QHBoxLayout(frame_4);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        fontCbx = new QFontComboBox(frame_4);
        fontCbx->setObjectName(QString::fromUtf8("fontCbx"));

        horizontalLayout_5->addWidget(fontCbx);

        sizeCbx = new QComboBox(frame_4);
        sizeCbx->addItem(QString());
        sizeCbx->addItem(QString());
        sizeCbx->addItem(QString());
        sizeCbx->addItem(QString());
        sizeCbx->addItem(QString());
        sizeCbx->addItem(QString());
        sizeCbx->addItem(QString());
        sizeCbx->addItem(QString());
        sizeCbx->addItem(QString());
        sizeCbx->addItem(QString());
        sizeCbx->addItem(QString());
        sizeCbx->addItem(QString());
        sizeCbx->addItem(QString());
        sizeCbx->addItem(QString());
        sizeCbx->addItem(QString());
        sizeCbx->setObjectName(QString::fromUtf8("sizeCbx"));

        horizontalLayout_5->addWidget(sizeCbx);

        boldTBtn = new QToolButton(frame_4);
        boldTBtn->setObjectName(QString::fromUtf8("boldTBtn"));
        boldTBtn->setMinimumSize(QSize(33, 33));
        QIcon icon;
        icon.addFile(QString::fromUtf8("QT/icon/bold.png"), QSize(), QIcon::Normal, QIcon::Off);
        boldTBtn->setIcon(icon);
        boldTBtn->setIconSize(QSize(26, 26));
        boldTBtn->setCheckable(true);

        horizontalLayout_5->addWidget(boldTBtn);

        italicTBtn = new QToolButton(frame_4);
        italicTBtn->setObjectName(QString::fromUtf8("italicTBtn"));
        italicTBtn->setMinimumSize(QSize(33, 33));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("QT/icon/italic.png"), QSize(), QIcon::Normal, QIcon::Off);
        italicTBtn->setIcon(icon1);
        italicTBtn->setIconSize(QSize(26, 26));
        italicTBtn->setCheckable(true);

        horizontalLayout_5->addWidget(italicTBtn);

        underlineTBtn = new QToolButton(frame_4);
        underlineTBtn->setObjectName(QString::fromUtf8("underlineTBtn"));
        underlineTBtn->setMinimumSize(QSize(33, 33));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("QT/icon/under.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        underlineTBtn->setIcon(icon2);
        underlineTBtn->setIconSize(QSize(26, 26));
        underlineTBtn->setCheckable(true);

        horizontalLayout_5->addWidget(underlineTBtn);

        colorTBtn = new QToolButton(frame_4);
        colorTBtn->setObjectName(QString::fromUtf8("colorTBtn"));
        colorTBtn->setMinimumSize(QSize(33, 33));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8("QT/icon/color.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        colorTBtn->setIcon(icon3);
        colorTBtn->setIconSize(QSize(26, 26));

        horizontalLayout_5->addWidget(colorTBtn);

        saveTBtn = new QToolButton(frame_4);
        saveTBtn->setObjectName(QString::fromUtf8("saveTBtn"));
        saveTBtn->setMinimumSize(QSize(33, 33));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8("QT/icon/save.png"), QSize(), QIcon::Normal, QIcon::Off);
        saveTBtn->setIcon(icon4);
        saveTBtn->setIconSize(QSize(26, 26));

        horizontalLayout_5->addWidget(saveTBtn);

        clearTBtn = new QToolButton(frame_4);
        clearTBtn->setObjectName(QString::fromUtf8("clearTBtn"));
        clearTBtn->setMinimumSize(QSize(33, 33));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8("QT/icon/clear.jpeg"), QSize(), QIcon::Normal, QIcon::Off);
        clearTBtn->setIcon(icon5);
        clearTBtn->setIconSize(QSize(26, 26));

        horizontalLayout_5->addWidget(clearTBtn);


        verticalLayout_4->addWidget(frame_4);

        msgTxtEdit = new QTextEdit(frame_3);
        msgTxtEdit->setObjectName(QString::fromUtf8("msgTxtEdit"));

        verticalLayout_4->addWidget(msgTxtEdit);


        horizontalLayout_4->addWidget(frame_3);

        usrTblWidget = new QTableWidget(groupChat);
        if (usrTblWidget->columnCount() < 1)
            usrTblWidget->setColumnCount(1);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        usrTblWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        usrTblWidget->setObjectName(QString::fromUtf8("usrTblWidget"));

        horizontalLayout_4->addWidget(usrTblWidget);


        verticalLayout_3->addLayout(horizontalLayout_4);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        sendBtn = new QPushButton(groupChat);
        sendBtn->setObjectName(QString::fromUtf8("sendBtn"));

        horizontalLayout_6->addWidget(sendBtn);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_3);

        usrNumLbl = new QLabel(groupChat);
        usrNumLbl->setObjectName(QString::fromUtf8("usrNumLbl"));

        horizontalLayout_6->addWidget(usrNumLbl);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_4);

        exitBtn = new QPushButton(groupChat);
        exitBtn->setObjectName(QString::fromUtf8("exitBtn"));

        horizontalLayout_6->addWidget(exitBtn);


        verticalLayout_3->addLayout(horizontalLayout_6);


        verticalLayout_5->addLayout(verticalLayout_3);


        retranslateUi(groupChat);

        sizeCbx->setCurrentIndex(4);


        QMetaObject::connectSlotsByName(groupChat);
    } // setupUi

    void retranslateUi(QWidget *groupChat)
    {
        groupChat->setWindowTitle(QApplication::translate("groupChat", "Form", nullptr));
        sizeCbx->setItemText(0, QApplication::translate("groupChat", "8", nullptr));
        sizeCbx->setItemText(1, QApplication::translate("groupChat", "9", nullptr));
        sizeCbx->setItemText(2, QApplication::translate("groupChat", "10", nullptr));
        sizeCbx->setItemText(3, QApplication::translate("groupChat", "11", nullptr));
        sizeCbx->setItemText(4, QApplication::translate("groupChat", "12", nullptr));
        sizeCbx->setItemText(5, QApplication::translate("groupChat", "13", nullptr));
        sizeCbx->setItemText(6, QApplication::translate("groupChat", "14", nullptr));
        sizeCbx->setItemText(7, QApplication::translate("groupChat", "15", nullptr));
        sizeCbx->setItemText(8, QApplication::translate("groupChat", "16", nullptr));
        sizeCbx->setItemText(9, QApplication::translate("groupChat", "17", nullptr));
        sizeCbx->setItemText(10, QApplication::translate("groupChat", "18", nullptr));
        sizeCbx->setItemText(11, QApplication::translate("groupChat", "19", nullptr));
        sizeCbx->setItemText(12, QApplication::translate("groupChat", "20", nullptr));
        sizeCbx->setItemText(13, QApplication::translate("groupChat", "21", nullptr));
        sizeCbx->setItemText(14, QApplication::translate("groupChat", "22", nullptr));

#ifndef QT_NO_TOOLTIP
        boldTBtn->setToolTip(QApplication::translate("groupChat", "\345\212\240\347\262\227", nullptr));
#endif // QT_NO_TOOLTIP
        boldTBtn->setText(QApplication::translate("groupChat", "...", nullptr));
#ifndef QT_NO_TOOLTIP
        italicTBtn->setToolTip(QApplication::translate("groupChat", "\346\226\234\344\275\223", nullptr));
#endif // QT_NO_TOOLTIP
        italicTBtn->setText(QApplication::translate("groupChat", "...", nullptr));
#ifndef QT_NO_TOOLTIP
        underlineTBtn->setToolTip(QApplication::translate("groupChat", "\344\270\213\345\210\222\347\272\277", nullptr));
#endif // QT_NO_TOOLTIP
        underlineTBtn->setText(QApplication::translate("groupChat", "...", nullptr));
#ifndef QT_NO_TOOLTIP
        colorTBtn->setToolTip(QApplication::translate("groupChat", "\346\215\242\351\242\234\350\211\262", nullptr));
#endif // QT_NO_TOOLTIP
        colorTBtn->setText(QApplication::translate("groupChat", "...", nullptr));
#ifndef QT_NO_TOOLTIP
        saveTBtn->setToolTip(QApplication::translate("groupChat", " \344\277\235\345\255\230\346\225\260\346\215\256", nullptr));
#endif // QT_NO_TOOLTIP
        saveTBtn->setText(QApplication::translate("groupChat", "...", nullptr));
#ifndef QT_NO_TOOLTIP
        clearTBtn->setToolTip(QApplication::translate("groupChat", "\346\270\205\347\251\272", nullptr));
#endif // QT_NO_TOOLTIP
        clearTBtn->setText(QApplication::translate("groupChat", "...", nullptr));
        QTableWidgetItem *___qtablewidgetitem = usrTblWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("groupChat", "\347\224\250\346\210\267\345\220\215", nullptr));
        sendBtn->setText(QApplication::translate("groupChat", "\345\217\221\351\200\201", nullptr));
        usrNumLbl->setText(QApplication::translate("groupChat", "\345\234\250\347\272\277\347\224\250\346\210\267\357\274\2320\344\272\272", nullptr));
        exitBtn->setText(QApplication::translate("groupChat", "\351\200\200\345\207\272", nullptr));
    } // retranslateUi

};

namespace Ui {
    class groupChat: public Ui_groupChat {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GROUPCHAT_H
