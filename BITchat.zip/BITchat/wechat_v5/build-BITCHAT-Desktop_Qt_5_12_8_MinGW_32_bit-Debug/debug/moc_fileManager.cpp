/****************************************************************************
** Meta object code from reading C++ file 'fileManager.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../BITCHAT/BITCHAT/fileManager.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fileManager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_FileManager_t {
    QByteArrayData data[23];
    char stringdata0[271];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_FileManager_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_FileManager_t qt_meta_stringdata_FileManager = {
    {
QT_MOC_LITERAL(0, 0, 11), // "FileManager"
QT_MOC_LITERAL(1, 12, 18), // "underwayCntChanged"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 18), // "finishDataRefrensh"
QT_MOC_LITERAL(4, 51, 4), // "list"
QT_MOC_LITERAL(5, 56, 16), // "onUploadFileTask"
QT_MOC_LITERAL(6, 73, 7), // "qintptr"
QT_MOC_LITERAL(7, 81, 16), // "socketDescriptor"
QT_MOC_LITERAL(8, 98, 15), // "newDownFileTask"
QT_MOC_LITERAL(9, 114, 9), // "fileLocal"
QT_MOC_LITERAL(10, 124, 10), // "fileTarget"
QT_MOC_LITERAL(11, 135, 8), // "fileSize"
QT_MOC_LITERAL(12, 144, 10), // "targetName"
QT_MOC_LITERAL(13, 155, 4), // "addr"
QT_MOC_LITERAL(14, 160, 4), // "port"
QT_MOC_LITERAL(15, 165, 15), // "getUnderwayData"
QT_MOC_LITERAL(16, 181, 18), // "removeUnderwayTask"
QT_MOC_LITERAL(17, 200, 2), // "id"
QT_MOC_LITERAL(18, 203, 7), // "fileUrl"
QT_MOC_LITERAL(19, 211, 25), // "requesetFinishDataRerensh"
QT_MOC_LITERAL(20, 237, 12), // "openExplorer"
QT_MOC_LITERAL(21, 250, 8), // "openFile"
QT_MOC_LITERAL(22, 259, 11) // "underwayCnt"

    },
    "FileManager\0underwayCntChanged\0\0"
    "finishDataRefrensh\0list\0onUploadFileTask\0"
    "qintptr\0socketDescriptor\0newDownFileTask\0"
    "fileLocal\0fileTarget\0fileSize\0targetName\0"
    "addr\0port\0getUnderwayData\0removeUnderwayTask\0"
    "id\0fileUrl\0requesetFinishDataRerensh\0"
    "openExplorer\0openFile\0underwayCnt"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_FileManager[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       1,   92, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   59,    2, 0x06 /* Public */,
       3,    1,   60,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    1,   63,    2, 0x08 /* Private */,

 // methods: name, argc, parameters, tag, flags
       8,    6,   66,    2, 0x02 /* Public */,
      15,    0,   79,    2, 0x02 /* Public */,
      16,    2,   80,    2, 0x02 /* Public */,
      19,    0,   85,    2, 0x02 /* Public */,
      20,    1,   86,    2, 0x02 /* Public */,
      21,    1,   89,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QVariantList,    4,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 6,    7,

 // methods: parameters
    QMetaType::Void, QMetaType::QUrl, QMetaType::QString, QMetaType::LongLong, QMetaType::QString, QMetaType::QString, QMetaType::Int,    9,   10,   11,   12,   13,   14,
    QMetaType::QVariantList,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   17,   18,
    QMetaType::Void,
    QMetaType::Bool, QMetaType::QString,    9,
    QMetaType::Bool, QMetaType::QString,    9,

 // properties: name, type, flags
      22, QMetaType::Int, 0x00495001,

 // properties: notify_signal_id
       0,

       0        // eod
};

void FileManager::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FileManager *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->underwayCntChanged(); break;
        case 1: _t->finishDataRefrensh((*reinterpret_cast< QVariantList(*)>(_a[1]))); break;
        case 2: _t->onUploadFileTask((*reinterpret_cast< qintptr(*)>(_a[1]))); break;
        case 3: _t->newDownFileTask((*reinterpret_cast< QUrl(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< qint64(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6]))); break;
        case 4: { QVariantList _r = _t->getUnderwayData();
            if (_a[0]) *reinterpret_cast< QVariantList*>(_a[0]) = std::move(_r); }  break;
        case 5: _t->removeUnderwayTask((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 6: _t->requesetFinishDataRerensh(); break;
        case 7: { bool _r = _t->openExplorer((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 8: { bool _r = _t->openFile((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FileManager::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FileManager::underwayCntChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (FileManager::*)(QVariantList );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FileManager::finishDataRefrensh)) {
                *result = 1;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<FileManager *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = _t->underwayCnt(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject FileManager::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_FileManager.data,
    qt_meta_data_FileManager,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *FileManager::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FileManager::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_FileManager.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int FileManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 9;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 1;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void FileManager::underwayCntChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void FileManager::finishDataRefrensh(QVariantList _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
