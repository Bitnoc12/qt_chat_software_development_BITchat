/****************************************************************************
** Meta object code from reading C++ file 'appcfg.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../BITCHAT/BITCHAT/common/AppCfg/appcfg.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'appcfg.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_AppCfg_t {
    QByteArrayData data[36];
    char stringdata0[451];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_AppCfg_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_AppCfg_t qt_meta_stringdata_AppCfg = {
    {
QT_MOC_LITERAL(0, 0, 6), // "AppCfg"
QT_MOC_LITERAL(1, 7, 18), // "currentUserChanged"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 18), // "fileOpenUrlChanged"
QT_MOC_LITERAL(4, 46, 16), // "headImageChanged"
QT_MOC_LITERAL(5, 63, 16), // "skinIndexChanged"
QT_MOC_LITERAL(6, 80, 18), // "bubbleIndexChanged"
QT_MOC_LITERAL(7, 99, 18), // "skinOpacityChanged"
QT_MOC_LITERAL(8, 118, 20), // "friendHeadDirChanged"
QT_MOC_LITERAL(9, 139, 21), // "headImageSmallChanged"
QT_MOC_LITERAL(10, 161, 11), // "writeUpdate"
QT_MOC_LITERAL(11, 173, 7), // "XmlName"
QT_MOC_LITERAL(12, 181, 4), // "name"
QT_MOC_LITERAL(13, 186, 12), // "writeXmlFile"
QT_MOC_LITERAL(14, 199, 15), // "updateHeadImage"
QT_MOC_LITERAL(15, 215, 3), // "url"
QT_MOC_LITERAL(16, 219, 11), // "currentUser"
QT_MOC_LITERAL(17, 231, 11), // "fileOpenUrl"
QT_MOC_LITERAL(18, 243, 9), // "headImage"
QT_MOC_LITERAL(19, 253, 9), // "skinIndex"
QT_MOC_LITERAL(20, 263, 11), // "bubbleIndex"
QT_MOC_LITERAL(21, 275, 11), // "skinOpacity"
QT_MOC_LITERAL(22, 287, 13), // "friendHeadDir"
QT_MOC_LITERAL(23, 301, 14), // "headImageSmall"
QT_MOC_LITERAL(24, 316, 5), // "Start"
QT_MOC_LITERAL(25, 322, 11), // "CurrentUser"
QT_MOC_LITERAL(26, 334, 9), // "HeadImage"
QT_MOC_LITERAL(27, 344, 11), // "FileOpenUrl"
QT_MOC_LITERAL(28, 356, 9), // "SkinIndex"
QT_MOC_LITERAL(29, 366, 11), // "BubbleIndex"
QT_MOC_LITERAL(30, 378, 11), // "SkinOpacity"
QT_MOC_LITERAL(31, 390, 13), // "FriendHeadDir"
QT_MOC_LITERAL(32, 404, 14), // "HeadImageSmall"
QT_MOC_LITERAL(33, 419, 13), // "ScreenCenterX"
QT_MOC_LITERAL(34, 433, 13), // "ScreenCenterY"
QT_MOC_LITERAL(35, 447, 3) // "End"

    },
    "AppCfg\0currentUserChanged\0\0"
    "fileOpenUrlChanged\0headImageChanged\0"
    "skinIndexChanged\0bubbleIndexChanged\0"
    "skinOpacityChanged\0friendHeadDirChanged\0"
    "headImageSmallChanged\0writeUpdate\0"
    "XmlName\0name\0writeXmlFile\0updateHeadImage\0"
    "url\0currentUser\0fileOpenUrl\0headImage\0"
    "skinIndex\0bubbleIndex\0skinOpacity\0"
    "friendHeadDir\0headImageSmall\0Start\0"
    "CurrentUser\0HeadImage\0FileOpenUrl\0"
    "SkinIndex\0BubbleIndex\0SkinOpacity\0"
    "FriendHeadDir\0HeadImageSmall\0ScreenCenterX\0"
    "ScreenCenterY\0End"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_AppCfg[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       8,   84, // properties
       1,  116, // enums/sets
       0,    0, // constructors
       0,       // flags
       9,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   69,    2, 0x06 /* Public */,
       3,    0,   70,    2, 0x06 /* Public */,
       4,    0,   71,    2, 0x06 /* Public */,
       5,    0,   72,    2, 0x06 /* Public */,
       6,    0,   73,    2, 0x06 /* Public */,
       7,    0,   74,    2, 0x06 /* Public */,
       8,    0,   75,    2, 0x06 /* Public */,
       9,    0,   76,    2, 0x06 /* Public */,
      10,    1,   77,    2, 0x06 /* Public */,

 // methods: name, argc, parameters, tag, flags
      13,    0,   80,    2, 0x02 /* Public */,
      14,    1,   81,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 11,   12,

 // methods: parameters
    QMetaType::Bool,
    QMetaType::Bool, QMetaType::QUrl,   15,

 // properties: name, type, flags
      16, QMetaType::QString, 0x00495003,
      17, QMetaType::QString, 0x00495003,
      18, QMetaType::QString, 0x00495003,
      19, QMetaType::QString, 0x00495003,
      20, QMetaType::QString, 0x00495003,
      21, QMetaType::QString, 0x00495003,
      22, QMetaType::QString, 0x00495003,
      23, QMetaType::QString, 0x00495003,

 // properties: notify_signal_id
       0,
       1,
       2,
       3,
       4,
       5,
       6,
       7,

 // enums: name, alias, flags, count, data
      11,   11, 0x0,   12,  121,

 // enum data: key, value
      24, uint(AppCfg::Start),
      25, uint(AppCfg::CurrentUser),
      26, uint(AppCfg::HeadImage),
      27, uint(AppCfg::FileOpenUrl),
      28, uint(AppCfg::SkinIndex),
      29, uint(AppCfg::BubbleIndex),
      30, uint(AppCfg::SkinOpacity),
      31, uint(AppCfg::FriendHeadDir),
      32, uint(AppCfg::HeadImageSmall),
      33, uint(AppCfg::ScreenCenterX),
      34, uint(AppCfg::ScreenCenterY),
      35, uint(AppCfg::End),

       0        // eod
};

void AppCfg::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<AppCfg *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->currentUserChanged(); break;
        case 1: _t->fileOpenUrlChanged(); break;
        case 2: _t->headImageChanged(); break;
        case 3: _t->skinIndexChanged(); break;
        case 4: _t->bubbleIndexChanged(); break;
        case 5: _t->skinOpacityChanged(); break;
        case 6: _t->friendHeadDirChanged(); break;
        case 7: _t->headImageSmallChanged(); break;
        case 8: _t->writeUpdate((*reinterpret_cast< XmlName(*)>(_a[1]))); break;
        case 9: { bool _r = _t->writeXmlFile();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 10: { bool _r = _t->updateHeadImage((*reinterpret_cast< QUrl(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (AppCfg::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&AppCfg::currentUserChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (AppCfg::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&AppCfg::fileOpenUrlChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (AppCfg::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&AppCfg::headImageChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (AppCfg::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&AppCfg::skinIndexChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (AppCfg::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&AppCfg::bubbleIndexChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (AppCfg::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&AppCfg::skinOpacityChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (AppCfg::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&AppCfg::friendHeadDirChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (AppCfg::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&AppCfg::headImageSmallChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (AppCfg::*)(XmlName );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&AppCfg::writeUpdate)) {
                *result = 8;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<AppCfg *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = _t->m_currentUser; break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->m_fileOpenUrl; break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->m_headImage; break;
        case 3: *reinterpret_cast< QString*>(_v) = _t->m_skinIndex; break;
        case 4: *reinterpret_cast< QString*>(_v) = _t->m_bubbleIndex; break;
        case 5: *reinterpret_cast< QString*>(_v) = _t->m_skinOpacity; break;
        case 6: *reinterpret_cast< QString*>(_v) = _t->m_friendHeadDir; break;
        case 7: *reinterpret_cast< QString*>(_v) = _t->m_headImageSmall; break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<AppCfg *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0:
            if (_t->m_currentUser != *reinterpret_cast< QString*>(_v)) {
                _t->m_currentUser = *reinterpret_cast< QString*>(_v);
                Q_EMIT _t->currentUserChanged();
            }
            break;
        case 1:
            if (_t->m_fileOpenUrl != *reinterpret_cast< QString*>(_v)) {
                _t->m_fileOpenUrl = *reinterpret_cast< QString*>(_v);
                Q_EMIT _t->fileOpenUrlChanged();
            }
            break;
        case 2:
            if (_t->m_headImage != *reinterpret_cast< QString*>(_v)) {
                _t->m_headImage = *reinterpret_cast< QString*>(_v);
                Q_EMIT _t->headImageChanged();
            }
            break;
        case 3:
            if (_t->m_skinIndex != *reinterpret_cast< QString*>(_v)) {
                _t->m_skinIndex = *reinterpret_cast< QString*>(_v);
                Q_EMIT _t->skinIndexChanged();
            }
            break;
        case 4:
            if (_t->m_bubbleIndex != *reinterpret_cast< QString*>(_v)) {
                _t->m_bubbleIndex = *reinterpret_cast< QString*>(_v);
                Q_EMIT _t->bubbleIndexChanged();
            }
            break;
        case 5:
            if (_t->m_skinOpacity != *reinterpret_cast< QString*>(_v)) {
                _t->m_skinOpacity = *reinterpret_cast< QString*>(_v);
                Q_EMIT _t->skinOpacityChanged();
            }
            break;
        case 6:
            if (_t->m_friendHeadDir != *reinterpret_cast< QString*>(_v)) {
                _t->m_friendHeadDir = *reinterpret_cast< QString*>(_v);
                Q_EMIT _t->friendHeadDirChanged();
            }
            break;
        case 7:
            if (_t->m_headImageSmall != *reinterpret_cast< QString*>(_v)) {
                _t->m_headImageSmall = *reinterpret_cast< QString*>(_v);
                Q_EMIT _t->headImageSmallChanged();
            }
            break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject AppCfg::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_AppCfg.data,
    qt_meta_data_AppCfg,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *AppCfg::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AppCfg::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_AppCfg.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int AppCfg::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 11;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 8;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void AppCfg::currentUserChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void AppCfg::fileOpenUrlChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void AppCfg::headImageChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void AppCfg::skinIndexChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void AppCfg::bubbleIndexChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void AppCfg::skinOpacityChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void AppCfg::friendHeadDirChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void AppCfg::headImageSmallChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void AppCfg::writeUpdate(XmlName _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
