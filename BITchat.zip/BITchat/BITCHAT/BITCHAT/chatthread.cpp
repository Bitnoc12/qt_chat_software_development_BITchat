#include "chatthread.h"

ChatThread::ChatThread(QThread *parent) : QThread(parent)
{

}
