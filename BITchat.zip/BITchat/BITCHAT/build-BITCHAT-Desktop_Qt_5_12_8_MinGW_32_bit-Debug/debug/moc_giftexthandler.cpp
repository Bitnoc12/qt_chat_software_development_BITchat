/****************************************************************************
** Meta object code from reading C++ file 'giftexthandler.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../wechat_v5/giftexthandler.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'giftexthandler.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_GifTextHandler_t {
    QByteArrayData data[17];
    char stringdata0[162];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GifTextHandler_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GifTextHandler_t qt_meta_stringdata_GifTextHandler = {
    {
QT_MOC_LITERAL(0, 0, 14), // "GifTextHandler"
QT_MOC_LITERAL(1, 15, 15), // "documentChanged"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 10), // "needUpdate"
QT_MOC_LITERAL(4, 43, 12), // "onMoveUpdate"
QT_MOC_LITERAL(5, 56, 5), // "inset"
QT_MOC_LITERAL(6, 62, 8), // "fileName"
QT_MOC_LITERAL(7, 71, 5), // "debug"
QT_MOC_LITERAL(8, 77, 6), // "coding"
QT_MOC_LITERAL(9, 84, 8), // "encoding"
QT_MOC_LITERAL(10, 93, 4), // "text"
QT_MOC_LITERAL(11, 98, 8), // "document"
QT_MOC_LITERAL(12, 107, 19), // "QQuickTextDocument*"
QT_MOC_LITERAL(13, 127, 11), // "cursorStart"
QT_MOC_LITERAL(14, 139, 9), // "cursorEnd"
QT_MOC_LITERAL(15, 149, 5), // "width"
QT_MOC_LITERAL(16, 155, 6) // "height"

    },
    "GifTextHandler\0documentChanged\0\0"
    "needUpdate\0onMoveUpdate\0inset\0fileName\0"
    "debug\0coding\0encoding\0text\0document\0"
    "QQuickTextDocument*\0cursorStart\0"
    "cursorEnd\0width\0height"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GifTextHandler[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       5,   60, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   49,    2, 0x06 /* Public */,
       3,    0,   50,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,   51,    2, 0x0a /* Public */,

 // methods: name, argc, parameters, tag, flags
       5,    1,   52,    2, 0x02 /* Public */,
       7,    0,   55,    2, 0x02 /* Public */,
       8,    0,   56,    2, 0x02 /* Public */,
       9,    1,   57,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,

 // methods: parameters
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void,
    QMetaType::QString,
    QMetaType::Void, QMetaType::QString,   10,

 // properties: name, type, flags
      11, 0x80000000 | 12, 0x0049510b,
      13, QMetaType::Int, 0x00095003,
      14, QMetaType::Int, 0x00095003,
      15, QMetaType::Int, 0x00095003,
      16, QMetaType::Int, 0x00095003,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,

       0        // eod
};

void GifTextHandler::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<GifTextHandler *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->documentChanged(); break;
        case 1: _t->needUpdate(); break;
        case 2: _t->onMoveUpdate(); break;
        case 3: _t->inset((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->debug(); break;
        case 5: { QString _r = _t->coding();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 6: _t->encoding((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (GifTextHandler::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GifTextHandler::documentChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (GifTextHandler::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GifTextHandler::needUpdate)) {
                *result = 1;
                return;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QQuickTextDocument* >(); break;
        }
    }

#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<GifTextHandler *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QQuickTextDocument**>(_v) = _t->document(); break;
        case 1: *reinterpret_cast< int*>(_v) = _t->m_cursorStart; break;
        case 2: *reinterpret_cast< int*>(_v) = _t->m_cursorEnd; break;
        case 3: *reinterpret_cast< int*>(_v) = _t->m_width; break;
        case 4: *reinterpret_cast< int*>(_v) = _t->m_height; break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<GifTextHandler *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setDocument(*reinterpret_cast< QQuickTextDocument**>(_v)); break;
        case 1:
            if (_t->m_cursorStart != *reinterpret_cast< int*>(_v)) {
                _t->m_cursorStart = *reinterpret_cast< int*>(_v);
            }
            break;
        case 2:
            if (_t->m_cursorEnd != *reinterpret_cast< int*>(_v)) {
                _t->m_cursorEnd = *reinterpret_cast< int*>(_v);
            }
            break;
        case 3:
            if (_t->m_width != *reinterpret_cast< int*>(_v)) {
                _t->m_width = *reinterpret_cast< int*>(_v);
            }
            break;
        case 4:
            if (_t->m_height != *reinterpret_cast< int*>(_v)) {
                _t->m_height = *reinterpret_cast< int*>(_v);
            }
            break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject GifTextHandler::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_GifTextHandler.data,
    qt_meta_data_GifTextHandler,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GifTextHandler::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GifTextHandler::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GifTextHandler.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int GifTextHandler::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void GifTextHandler::documentChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void GifTextHandler::needUpdate()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
