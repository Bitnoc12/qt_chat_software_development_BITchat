/****************************************************************************
** Meta object code from reading C++ file 'friend_model.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../wechat_v5/friend_model.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'friend_model.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_FriendModel_t {
    QByteArrayData data[29];
    char stringdata0[295];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_FriendModel_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_FriendModel_t qt_meta_stringdata_FriendModel = {
    {
QT_MOC_LITERAL(0, 0, 11), // "FriendModel"
QT_MOC_LITERAL(1, 12, 11), // "loginResult"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 6), // "result"
QT_MOC_LITERAL(4, 32, 24), // "chatChangeStartAnimation"
QT_MOC_LITERAL(5, 57, 21), // "removeFriendcloseChat"
QT_MOC_LITERAL(6, 79, 10), // "initialize"
QT_MOC_LITERAL(7, 90, 11), // "dataChanged"
QT_MOC_LITERAL(8, 102, 5), // "rowId"
QT_MOC_LITERAL(9, 108, 6), // "errMsg"
QT_MOC_LITERAL(10, 115, 3), // "msg"
QT_MOC_LITERAL(11, 119, 10), // "successMsg"
QT_MOC_LITERAL(12, 130, 11), // "onMsgUpdate"
QT_MOC_LITERAL(13, 142, 11), // "returnLogin"
QT_MOC_LITERAL(14, 154, 11), // "currentChat"
QT_MOC_LITERAL(15, 166, 16), // "FriendChatModel*"
QT_MOC_LITERAL(16, 183, 9), // "enterChat"
QT_MOC_LITERAL(17, 193, 4), // "user"
QT_MOC_LITERAL(18, 198, 9), // "closeChat"
QT_MOC_LITERAL(19, 208, 5), // "model"
QT_MOC_LITERAL(20, 214, 7), // "sendMsg"
QT_MOC_LITERAL(21, 222, 4), // "text"
QT_MOC_LITERAL(22, 227, 8), // "sendFile"
QT_MOC_LITERAL(23, 236, 9), // "fileLocal"
QT_MOC_LITERAL(24, 246, 13), // "cleanChatData"
QT_MOC_LITERAL(25, 260, 5), // "login"
QT_MOC_LITERAL(26, 266, 3), // "pwd"
QT_MOC_LITERAL(27, 270, 9), // "clipboard"
QT_MOC_LITERAL(28, 280, 14) // "friendIsOnline"

    },
    "FriendModel\0loginResult\0\0result\0"
    "chatChangeStartAnimation\0removeFriendcloseChat\0"
    "initialize\0dataChanged\0rowId\0errMsg\0"
    "msg\0successMsg\0onMsgUpdate\0returnLogin\0"
    "currentChat\0FriendChatModel*\0enterChat\0"
    "user\0closeChat\0model\0sendMsg\0text\0"
    "sendFile\0fileLocal\0cleanChatData\0login\0"
    "pwd\0clipboard\0friendIsOnline"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_FriendModel[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  104,    2, 0x06 /* Public */,
       4,    0,  107,    2, 0x06 /* Public */,
       5,    0,  108,    2, 0x06 /* Public */,
       6,    0,  109,    2, 0x06 /* Public */,
       7,    1,  110,    2, 0x06 /* Public */,
       9,    1,  113,    2, 0x06 /* Public */,
      11,    1,  116,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      12,    0,  119,    2, 0x0a /* Public */,

 // methods: name, argc, parameters, tag, flags
      13,    0,  120,    2, 0x02 /* Public */,
      14,    0,  121,    2, 0x02 /* Public */,
      16,    1,  122,    2, 0x02 /* Public */,
      18,    1,  125,    2, 0x02 /* Public */,
      20,    1,  128,    2, 0x02 /* Public */,
      22,    1,  131,    2, 0x02 /* Public */,
      24,    0,  134,    2, 0x02 /* Public */,
      25,    2,  135,    2, 0x02 /* Public */,
      27,    1,  140,    2, 0x02 /* Public */,
      28,    1,  143,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::QString,   10,

 // slots: parameters
    QMetaType::Void,

 // methods: parameters
    QMetaType::Void,
    0x80000000 | 15,
    QMetaType::Void, QMetaType::QString,   17,
    QMetaType::Void, 0x80000000 | 15,   19,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void, QMetaType::QUrl,   23,
    QMetaType::Void,
    QMetaType::QString, QMetaType::QString, QMetaType::QString,   17,   26,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Bool, QMetaType::QString,   17,

       0        // eod
};

void FriendModel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FriendModel *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->loginResult((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->chatChangeStartAnimation(); break;
        case 2: _t->removeFriendcloseChat(); break;
        case 3: _t->initialize(); break;
        case 4: _t->dataChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->errMsg((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 6: _t->successMsg((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->onMsgUpdate(); break;
        case 8: _t->returnLogin(); break;
        case 9: { FriendChatModel* _r = _t->currentChat();
            if (_a[0]) *reinterpret_cast< FriendChatModel**>(_a[0]) = std::move(_r); }  break;
        case 10: _t->enterChat((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 11: _t->closeChat((*reinterpret_cast< FriendChatModel*(*)>(_a[1]))); break;
        case 12: _t->sendMsg((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 13: _t->sendFile((*reinterpret_cast< QUrl(*)>(_a[1]))); break;
        case 14: _t->cleanChatData(); break;
        case 15: { QString _r = _t->login((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 16: _t->clipboard((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 17: { bool _r = _t->friendIsOnline((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 11:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< FriendChatModel* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FriendModel::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FriendModel::loginResult)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (FriendModel::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FriendModel::chatChangeStartAnimation)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (FriendModel::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FriendModel::removeFriendcloseChat)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (FriendModel::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FriendModel::initialize)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (FriendModel::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FriendModel::dataChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (FriendModel::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FriendModel::errMsg)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (FriendModel::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FriendModel::successMsg)) {
                *result = 6;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject FriendModel::staticMetaObject = { {
    &QAbstractListModel::staticMetaObject,
    qt_meta_stringdata_FriendModel.data,
    qt_meta_data_FriendModel,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *FriendModel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FriendModel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_FriendModel.stringdata0))
        return static_cast<void*>(this);
    return QAbstractListModel::qt_metacast(_clname);
}

int FriendModel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QAbstractListModel::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    }
    return _id;
}

// SIGNAL 0
void FriendModel::loginResult(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void FriendModel::chatChangeStartAnimation()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void FriendModel::removeFriendcloseChat()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void FriendModel::initialize()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void FriendModel::dataChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void FriendModel::errMsg(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void FriendModel::successMsg(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
